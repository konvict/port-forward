#!/bin/sh

kill `cat port-forward.pid`
rm -rf port-forward.pid


