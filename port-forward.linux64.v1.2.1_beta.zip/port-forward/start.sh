#!/bin/sh

nohup ./port-forward > console.log 2>&1 &
echo $! > port-forward.pid


