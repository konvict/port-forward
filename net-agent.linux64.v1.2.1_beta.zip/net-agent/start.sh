#!/bin/sh

nohup ./net-agent > console.log 2>&1 &
echo $! > net-agent.pid


