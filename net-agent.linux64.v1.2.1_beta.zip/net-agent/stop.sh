#!/bin/sh

kill `cat net-agent.pid`
rm -rf net-agent.pid


